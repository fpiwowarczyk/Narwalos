#ifndef Zycie_h
#define Zycie_h
#include<SDL.h>
#include<SDL_image.h>

class zycia
{
public:
	zycia(int x,int y);
	~zycia();
	void ladowanie(SDL_Renderer* Render);
	void rysuj(SDL_Renderer* Render);
	bool getwidzialne();

private:

	int posX, posY;
	SDL_Rect  prostokat;
	bool widzialne=1;
};

#endif