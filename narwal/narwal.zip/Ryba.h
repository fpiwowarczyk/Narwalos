#ifndef RYBA_H
#define RYBA_H

#include<SDL.h>
class Ryba
{
public:

	Ryba(int x,int y);
	~Ryba();
	void rysuj(SDL_Renderer* Render);
	void ladowanie(SDL_Renderer* Render);
	void move();
	int getx();
	int gety();
	void zmienX();
	void zmienY();


private:
	int posX, posY;
	SDL_Rect rect;
	int predkosc=4;

};

#endif