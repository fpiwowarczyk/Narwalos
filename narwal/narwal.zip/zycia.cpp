#include"zycia.h"
#include"Textura.h"
#include<SDL.h>
#include<SDL_image.h>
#include<vector>
#include<time.h>
#include<Windows.h>
#include<math.h>
#include<iostream>

textura zyc;
zycia::zycia(int x,int y)
{
	posX = x;
	posY = y;
}

zycia::~zycia()
{
	zyc.zwolnij();

}

void zycia::ladowanie(SDL_Renderer* Render)
{
	zyc.laduj("Obrazki/zycie.png", Render);
	prostokat.h = 64;
	prostokat.w = 64;
	prostokat.x = 0;
	prostokat.y =0;
}

void zycia::rysuj(SDL_Renderer* Render)
{
	if (widzialne == 1)
	{
		SDL_Rect* clip = &prostokat;
		zyc.render(posX, posY, clip, Render);
	
	}
	else
	{
		
	}

}
bool zycia::getwidzialne()
{
	return widzialne;
}