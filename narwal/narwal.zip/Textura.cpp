
#include <SDL.h>
#include <SDL_image.h>
#include <stdio.h>
#include <string>
#include"Textura.h"

//Konstruktory
textura::textura()
{
	mWidth = 0;
	mHeight = 0;
	mTexture = NULL;
}
textura::~textura()
{
	zwolnij();
}

bool textura::laduj(std::string path,SDL_Renderer* Render)
{
	zwolnij();

	SDL_Texture* newTexture = NULL;

	SDL_Surface* loadedSurface = IMG_Load(path.c_str());

	SDL_SetColorKey(loadedSurface, SDL_TRUE, SDL_MapRGB(loadedSurface->format, 0, 0xFF, 0xFF));

	
	newTexture = SDL_CreateTextureFromSurface(Render, loadedSurface);

	mWidth = loadedSurface->w;
	mHeight = loadedSurface->h;

	SDL_FreeSurface(loadedSurface);

	mTexture = newTexture;
	return mTexture != NULL;

}


void textura::zwolnij()
{
	if (mTexture != NULL)
	{
		SDL_DestroyTexture(mTexture);
		mTexture = NULL;
		mWidth = 0;
		mHeight = 0;
	}
}

void textura::ustawKolor(Uint8 red, Uint8 green, Uint8 blue)
{

	SDL_SetTextureColorMod(mTexture, red, green, blue);
}


void textura::setBlendMode(SDL_BlendMode blending)
{

	SDL_SetTextureBlendMode(mTexture, blending);
}


void textura::setAlpha(Uint8 alpha)
{

	SDL_SetTextureAlphaMod(mTexture, alpha);
}


void textura::render(int x, int y, SDL_Rect* clip, SDL_Renderer* Render)
{

	//Set rendering space and render to screen
	SDL_Rect renderQuad = { x, y, mWidth, mHeight };

	//Set clip rendering dimensions
	if (clip != NULL)
	{
		renderQuad.w = clip->w;
		renderQuad.h = clip->h;
	}

	//Render to screen
	SDL_RenderCopy(Render, mTexture, clip, &renderQuad);
}

int textura::getWidth()
{
	return mWidth;
}
int textura::getHeight()
{
	 return mHeight;
}


bool textura::loadFromRenderedText(std::string textureText, SDL_Color textColor, TTF_Font *gFont, SDL_Renderer* Render)
{
	zwolnij();
	SDL_Surface* textSurface = TTF_RenderText_Solid(gFont, textureText.c_str(), textColor);
	mTexture = SDL_CreateTextureFromSurface(Render, textSurface);
	mWidth = textSurface->w;
	mHeight = textSurface->h;
	SDL_FreeSurface(textSurface);

	return mTexture;
}

