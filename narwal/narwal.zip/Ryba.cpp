#include"Ryba.h"
#include"Textura.h"
#include<iostream>

textura rybos;
Ryba::Ryba(int x,int y)
{
	posX = x;
	posY = y;
}

Ryba::~Ryba()
{
	rybos.zwolnij();
}

void Ryba::ladowanie(SDL_Renderer* Render)
{
	rybos.laduj("Obrazki/ryba.png", Render);
	rect.x = 0;
	rect.y = 0;
	rect.w = 32;
	rect.h = 16;
}

void Ryba::rysuj(SDL_Renderer* Render)
{

	SDL_Rect* clip = &rect;
	rybos.render(posX, posY, clip, Render);

}

void Ryba::move()
{
	posX = posX - predkosc;
	if (posX == -100)
	{
		posX = rand() % 3000 + 1600;
	}
}
int Ryba::getx()
{
	return posX;
}

int Ryba::gety()
{
	return posY;
}

void Ryba::zmienX()
{
	posX = rand() % 2900 + 1600;

}

void Ryba::zmienY()
{
	posY = rand() % 480 + 150;
}