#ifndef TEXTRUA_H
#define TEXTURA_H
#include <SDL.h>
#include <SDL_image.h>
#include<SDL_ttf.h>
#include <stdio.h>
#include <string>
class textura
{
public:
	//Konstruktory
	textura();
	~textura();

	bool laduj(std::string patch, SDL_Renderer* Render);
	
	bool loadFromRenderedText(std::string textureText, SDL_Color textColor, TTF_Font *gFont, SDL_Renderer* Render);

	void zwolnij();

	void ustawKolor(Uint8 red, Uint8 green, Uint8 blue);

	void setBlendMode(SDL_BlendMode blending);

	void setAlpha(Uint8 alpha);

	void render(int x, int y, SDL_Rect* clip = NULL , SDL_Renderer* Render=NULL);

	int getWidth();
	int getHeight();

private:

	//The actual hardware texture
	SDL_Texture* mTexture;

	//Image dimensions
	int mWidth;
	int mHeight;


};

#endif