#ifndef FLS_H
#define FPS_H

class fps
{
public:
	int fps_poczatek;
	int fps_koniec;
	int roznica;
	float delay;


	void start();
	void koniec();
};

#endif