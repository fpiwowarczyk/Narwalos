STEROWANIE WSAD 


DO OSZUKIWANIA P i Q szybkie poruszanie